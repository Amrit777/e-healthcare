
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->

    <script src="../js/custom.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="../js/bootstrap.min.js"></script>
    <script src='../js/bootstrap-select.min.js'></script>
</body>

</html>

