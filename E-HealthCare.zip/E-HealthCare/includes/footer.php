<head>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="StyleSheet.css" rel="stylesheet" type="text/css" />

</head>
<div class="ftr-bg">
<div class="wrap">
<div class="footer">
	<div class="f_nav">
		<ul>
			<li class="active"><a href="index.php">Home</a></li>			
			<li><a href="donar.php">Donor</a></li>
            <li><a href="login.php">log In</a></li>
            <li><a href="aboutus.php">About</a></li>
            <li><a href="contact.php">Contact Us</a></li>
			
            </ul>
	</div>
	<div class="clear"></div>
</div>
</div>
</div>