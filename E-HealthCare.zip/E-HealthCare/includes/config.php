<?php
//error_reporting(1);
$con=mysqli_connect("localhost","root","","finalhospital") or die('datbase connection error');
 
?>